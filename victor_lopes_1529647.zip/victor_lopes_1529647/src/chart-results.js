
const jsonFilePath = 'models/result_model.json';

/* Para o carregamento do gráfico, os dados estão sendo adquiridos via JSON que seria criado e obtido ao final do quiz, 
porém como a lógica não está implementada para obter os dados personalizados, está sendo utilizado um JSON de exemplo, que é editável
e que o formato deve ser seguido na lógica de envio dos dados também.*/

// Função para carregar o arquivo JSON
async function loadJSON() {
    try {
        const response = await fetch(jsonFilePath);
        const data = await response.json();
        return data;
    } catch (e) {
        console.e(`Erro ao carregar o arquivo JSON: ${e}`);
        return null;
    }
}

// Chama a função para carregar o JSON e criar o gráfico
loadJSON().then(jsonData => {
    if (!jsonData) return; // Retorna se o JSON não foi carregado
    console.log(jsonData)

    chartData = [];

    for (const key in jsonData) {
        chartData.push(jsonData[key]);
    }
    console.log(chartData);

    const labels = ['Ciências Humanas', 'Ciências Exatas', 'Ciências Sociais', 'Ciências Biológicas', 'Tecnologia',]; //Isso aqui define quais "porções" vão ter no gráfico
    const data = [chartData[0], chartData[1], chartData[2], chartData[3], chartData[4]]; //Isso aqui define as porcentagens de cada uma respectivamente (o primeiro numero dessa linha corresponde à primeira categoria da linha de cima e assim por diante)

    const config = { //Aqui são as configurações do gráfico, para mudar o tipo, só mudar esse parametro "type"
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{ data: data }]
        },
    };

    let myChart = document.getElementById('results-chart').getContext('2d'); //Aqui puxa o id da tag <canvas> lá do HTML, que é onde vai desenhar o gráfico

    let resultsChart = new Chart(myChart, config); //aqui desenha o grafico no local especificado



})

//essa parte é a que faz o gráfico aparecer quando clica no botão "mostrar resultados":

const toggleButton = document.getElementById('toggle-show-results');
const results = document.getElementById('chart-container');

toggleButton.addEventListener('click', function () {
    results.classList.toggle('is-hidden'); //Ao clicar no botão, remove a classe "is-hidden", mostrando o resultado
});
